## API utilizada

- Nome: Open-Meteo
- Documentação: https://open-meteo.com/en/docs
- Busca de cidades: `https://geocoding-api.open-meteo.com/v1/search?name={cidade}`
- Previsão do tempo: `https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}`
- Autenticação: não é necessária.

