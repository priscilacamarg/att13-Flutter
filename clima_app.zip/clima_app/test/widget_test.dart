import 'package:clima_app/models/clima.dart';
import 'package:clima_app/utils/clima_utils.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Clima.fromJson interpreta o JSON da Open-Meteo', () {
    final json = {
      'current': {
        'temperature_2m': 21.5,
        'apparent_temperature': 20.0,
        'relative_humidity_2m': 70,
        'wind_speed_10m': 12.3,
        'weather_code': 3,
      },
      'daily': {
        'time': ['2026-11-05', '2026-11-06'],
        'weather_code': [0, 61],
        'temperature_2m_max': [25.4, 22.0],
        'temperature_2m_min': [14.1, 13.0],
      },
    };

    final clima = Clima.fromJson(json);

    expect(clima.temperatura, 21.5);
    expect(clima.umidade, 70);
    expect(clima.dias.length, 2);
    expect(clima.dias[1].codigo, 61);
  });

  test('descricaoClima traduz códigos WMO', () {
    expect(descricaoClima(0), 'Céu limpo');
    expect(descricaoClima(61), 'Chuva');
    expect(descricaoClima(95), 'Tempestade');
  });
}
