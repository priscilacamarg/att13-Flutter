class Cidade {
  final String nome;
  final String? estado;
  final String pais;
  final double latitude;
  final double longitude;

  Cidade({
    required this.nome,
    required this.estado,
    required this.pais,
    required this.latitude,
    required this.longitude,
  });

  factory Cidade.fromJson(Map<String, dynamic> json) => Cidade(
        nome: json['name'],
        estado: json['admin1'],
        pais: json['country'] ?? '',
        latitude: (json['latitude'] as num).toDouble(),
        longitude: (json['longitude'] as num).toDouble(),
      );

  String get descricao => [if (estado != null) estado!, pais].join(', ');
}
