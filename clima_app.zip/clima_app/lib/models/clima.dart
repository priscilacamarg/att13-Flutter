class DiaPrevisao {
  final DateTime data;
  final int codigo;
  final double maxima;
  final double minima;

  DiaPrevisao({
    required this.data,
    required this.codigo,
    required this.maxima,
    required this.minima,
  });
}

class Clima {
  final double temperatura;
  final double sensacao;
  final int umidade;
  final double vento;
  final int codigo;
  final List<DiaPrevisao> dias;

  Clima({
    required this.temperatura,
    required this.sensacao,
    required this.umidade,
    required this.vento,
    required this.codigo,
    required this.dias,
  });

  factory Clima.fromJson(Map<String, dynamic> json) {
    final atual = json['current'];
    final diario = json['daily'];
    final datas = diario['time'] as List;

    return Clima(
      temperatura: (atual['temperature_2m'] as num).toDouble(),
      sensacao: (atual['apparent_temperature'] as num).toDouble(),
      umidade: (atual['relative_humidity_2m'] as num).toInt(),
      vento: (atual['wind_speed_10m'] as num).toDouble(),
      codigo: (atual['weather_code'] as num).toInt(),
      dias: List.generate(
        datas.length,
        (i) => DiaPrevisao(
          data: DateTime.parse(datas[i]),
          codigo: (diario['weather_code'][i] as num).toInt(),
          maxima: (diario['temperature_2m_max'][i] as num).toDouble(),
          minima: (diario['temperature_2m_min'][i] as num).toDouble(),
        ),
      ),
    );
  }
}
