import 'package:flutter/material.dart';

import '../models/cidade.dart';
import '../services/open_meteo_service.dart';
import 'tela_clima.dart';

class TelaBusca extends StatefulWidget {
  const TelaBusca({super.key});

  @override
  State<TelaBusca> createState() => _TelaBuscaState();
}

class _TelaBuscaState extends State<TelaBusca> {
  final _servico = OpenMeteoService();
  final _controlador = TextEditingController(text: 'Guarapuava');
  Future<List<Cidade>>? _futuroCidades;

  @override
  void initState() {
    super.initState();
    _futuroCidades = _servico.buscarCidades(_controlador.text);
  }

  @override
  void dispose() {
    _controlador.dispose();
    super.dispose();
  }

  void _buscar() {
    if (_controlador.text.trim().isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() => _futuroCidades = _servico.buscarCidades(_controlador.text));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Previsão do Tempo'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _controlador,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _buscar(),
              decoration: InputDecoration(
                hintText: 'Digite o nome da cidade',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: _buscar),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Cidade>>(
              future: _futuroCidades,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        snapshot.error.toString().replaceFirst('Exception: ', ''),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                final cidades = snapshot.data ?? [];
                return ListView.builder(
                  itemCount: cidades.length,
                  itemBuilder: (context, i) {
                    final c = cidades[i];
                    return ListTile(
                      leading: const Icon(Icons.location_on_outlined),
                      title: Text(c.nome),
                      subtitle: Text(c.descricao),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => TelaClima(cidade: c)),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
