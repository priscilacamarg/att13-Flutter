import 'package:flutter/material.dart';

import '../models/cidade.dart';
import '../models/clima.dart';
import '../services/open_meteo_service.dart';
import '../utils/clima_utils.dart';

class TelaClima extends StatefulWidget {
  final Cidade cidade;
  const TelaClima({super.key, required this.cidade});

  @override
  State<TelaClima> createState() => _TelaClimaState();
}

class _TelaClimaState extends State<TelaClima> {
  late Future<Clima> _futuroClima;

  @override
  void initState() {
    super.initState();
    _futuroClima = OpenMeteoService().buscarClima(widget.cidade);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.cidade.nome)),
      body: FutureBuilder<Clima>(
        future: _futuroClima,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  snapshot.error.toString().replaceFirst('Exception: ', ''),
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          final clima = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                color: Theme.of(context).colorScheme.primaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text(widget.cidade.descricao),
                      const SizedBox(height: 8),
                      Icon(iconeClima(clima.codigo), size: 80),
                      Text(
                        '${clima.temperatura.round()}°C',
                        style: Theme.of(context).textTheme.displayMedium,
                      ),
                      Text(descricaoClima(clima.codigo),
                          style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _info(Icons.thermostat, 'Sensação', '${clima.sensacao.round()}°C'),
                          _info(Icons.water_drop_outlined, 'Umidade', '${clima.umidade}%'),
                          _info(Icons.air, 'Vento', '${clima.vento.round()} km/h'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text('Próximos dias', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              ...clima.dias.map(
                (d) => Card(
                  child: ListTile(
                    leading: Icon(iconeClima(d.codigo)),
                    title: Text('${diaSemana(d.data)}  ${dataCurta(d.data)}'),
                    subtitle: Text(descricaoClima(d.codigo)),
                    trailing: Text(
                      '${d.minima.round()}° / ${d.maxima.round()}°',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _info(IconData icone, String titulo, String valor) => Column(
        children: [
          Icon(icone),
          Text(titulo, style: const TextStyle(fontSize: 12)),
          Text(valor, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      );
}
