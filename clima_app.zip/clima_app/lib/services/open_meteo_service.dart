import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/cidade.dart';
import '../models/clima.dart';

/// Serviço que consome a API Open-Meteo.
///   Geocoding: https://geocoding-api.open-meteo.com/v1/search
///   Previsão:  https://api.open-meteo.com/v1/forecast
class OpenMeteoService {
  Future<List<Cidade>> buscarCidades(String nome) async {
    final uri = Uri.https('geocoding-api.open-meteo.com', '/v1/search', {
      'name': nome.trim(),
      'count': '8',
      'language': 'pt',
    });

    final resposta = await http.get(uri);
    if (resposta.statusCode != 200) {
      throw Exception('Erro ao buscar cidades (código ${resposta.statusCode}).');
    }

    final dados = jsonDecode(resposta.body);
    final resultados = dados['results'] as List?;
    if (resultados == null || resultados.isEmpty) {
      throw Exception('Nenhuma cidade encontrada para "$nome".');
    }
    return resultados.map((e) => Cidade.fromJson(e)).toList();
  }

  Future<Clima> buscarClima(Cidade cidade) async {
    final uri = Uri.https('api.open-meteo.com', '/v1/forecast', {
      'latitude': cidade.latitude.toString(),
      'longitude': cidade.longitude.toString(),
      'current': 'temperature_2m,relative_humidity_2m,apparent_temperature,'
          'wind_speed_10m,weather_code',
      'daily': 'weather_code,temperature_2m_max,temperature_2m_min',
      'timezone': 'auto',
    });

    final resposta = await http.get(uri);
    if (resposta.statusCode != 200) {
      throw Exception('Erro ao buscar a previsão (código ${resposta.statusCode}).');
    }
    return Clima.fromJson(jsonDecode(resposta.body));
  }
}
