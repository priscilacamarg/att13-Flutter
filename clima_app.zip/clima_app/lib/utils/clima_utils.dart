import 'package:flutter/material.dart';

/// Descrição textual dos códigos WMO usados pela Open-Meteo.
String descricaoClima(int codigo) {
  if (codigo == 0) return 'Céu limpo';
  if (codigo <= 2) return 'Parcialmente nublado';
  if (codigo == 3) return 'Nublado';
  if (codigo == 45 || codigo == 48) return 'Neblina';
  if (codigo >= 51 && codigo <= 57) return 'Garoa';
  if (codigo >= 61 && codigo <= 67) return 'Chuva';
  if (codigo >= 71 && codigo <= 77) return 'Neve';
  if (codigo >= 80 && codigo <= 82) return 'Pancadas de chuva';
  if (codigo >= 95) return 'Tempestade';
  return 'Indefinido';
}

IconData iconeClima(int codigo) {
  if (codigo == 0) return Icons.wb_sunny;
  if (codigo <= 2) return Icons.wb_cloudy_outlined;
  if (codigo == 3) return Icons.cloud;
  if (codigo == 45 || codigo == 48) return Icons.foggy;
  if (codigo >= 51 && codigo <= 67) return Icons.grain;
  if (codigo >= 71 && codigo <= 77) return Icons.ac_unit;
  if (codigo >= 80 && codigo <= 82) return Icons.water_drop;
  if (codigo >= 95) return Icons.thunderstorm;
  return Icons.help_outline;
}

String diaSemana(DateTime d) =>
    const ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'][d.weekday - 1];

String dataCurta(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';
